const app = require('./backend/app');
app.listen(3000, ()=> {
    console.log('Listening on PORT 3000');
});